<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coaches extends MX_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->model(array('Model'));
    } 
    
	public function index()
	{		
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = ['e.coach_id'=>$this->nativesession->get('id')];
		$data['allEvents'] = $this->Model->getAllEvents($where);
		$this->heading($row);
		$this->load->view('events',$data);
		$this->load->view('footer');
	} 

	public function insert_event(){
		$this->checkAccountNotNull();
		$coach_id = $this->nativesession->get('id');
		$event = $this->input->post('event');
		$description = $this->input->post('description');
		$date = $this->input->post('date');
		$start_time = $this->input->post('start_time');
		$end_time = $this->input->post('end_time');
		$data = [
			'coach_id' => $coach_id,
			'event_name' => $event,
			'description' => $description,
			'date' => date('Y-m-d',strtotime($date)),
			'start_time' => $start_time,
			'end_time' => $end_time
		];
		// var_dump($data);exit;
		$this->Model->insertData('events',$data);
		$message = base64_encode("success~Event successfully saved.");
		redirect(base_url('coaches/?m='.$message));
	}

	public function update_event(){
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$event = $this->input->post('up_event');
		$description = $this->input->post('up_description');
		$date = $this->input->post('up_date');
		$start_time = $this->input->post('up_start_time');
		$end_time = $this->input->post('up_end_time');
		$data = [
			'event_name' => $event,
			'description' => $description,
			'date' => date('Y-m-d',strtotime($date)),
			'start_time' => $start_time,
			'end_time' => $end_time
		];
		// var_dump($data);exit;
		$this->Model->update('events',$data,$where);
		$message = base64_encode("success~Event successfully updated.");
		redirect(base_url('coaches/?m='.$message));
	}

	public function delete_events(){
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$this->Model->deleteData('events',$where);
		$message =  base64_encode("errorrr~Event successfully deleted.");
		redirect(base_url('coaches/?m='.$message));
	}

	public function athletes(){
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = ['i.sports'=>$row->sports,'a.usertype'=>3];
		$data['allData'] = $this->Model->getAthletes($where);
		$data['sport'] = $row->sports;
		$this->heading($row);
		$this->load->view('athletes',$data);
		$this->load->view('footer');
	}

	public function insert_athletes(){	
		$this->checkAccountNotNull();
		$username = $this->input->post('id_number');
		$where = array(
			'username' => $username
		);
		$checkUN = $this->Model->CheckAccount('accounts',$where);
		if($checkUN == NULL){
			$gender = $this->input->post('gender');
			$sport = $this->input->post('sport');
			$fname = $this->input->post('fname');
			$lname = $this->input->post('lname');
			$course = $this->input->post('course');
			$address = $this->input->post('address');
			$datebirth = $this->input->post('datebirth');
			$course_yr = $this->input->post('course_yr');

			$config['upload_path'] = FCPATH."assets\images";
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = 100000;
      $config['max_width'] = 5000;
      $config['max_height'] = 5000;

      $this->load->library('upload', $config);
      $image_name = $_FILES['pro_pic']['name'];
      $image_path = './assets/pro_pic_images/'.$image_name;
      	if(!$this->upload->do_upload('pro_pic')){
            $message1 = $this->upload->display_errors();
            if('You did not select a file to upload.' == $message1){
            	$message = base64_encode("success~New user successfully added. The profile picture is default image because you didn't select an image.");
            } else {
            	$message =  base64_encode("success~".$message1);
            }
            
            $image_path = 'pro_pic_icon_admin.png';
        } else {
        	$image_path = $this->upload->data()['file_name'];
        	$message = base64_encode('success~New user successfully added.');
        }

        $accounts_data = [
					"username" => $username,
					"password" => base64_encode(md5('123456')),
					"pro_pic" => $image_path,
					"usertype" => 3
				];

				$account_id = $this->Model->insertData('accounts',$accounts_data);
		        
		    $info_data = [
					"account_id" => $account_id,
					"firstname" => $fname,
					"lastname" => $lname,
					"birthdate" => date('Y-m-d',strtotime($datebirth)),
					"address" => $address,
					"course" => $course,
					"gender" => $gender,
					"sports" => $sport
				];
				$check = $this->Model->insertData('information',$info_data);
				if($check != NULL){
        	$message = base64_encode('success~New user successfully added.');
				} else {
					$message = base64_encode("errorrr~There's an error in saving the data. Please contact the Developer.");
				}	
    } else {
    	$message = base64_encode('errorrr~Username has been used.');
    }
   	redirect(base_url('coaches/athletes/?m='.$message));
	}

	public function delete_athletes(){
		$this->checkAccountNotNull();
		$where1 = ['id'=>$this->uri->segment(3)];
		$this->Model->deleteData('accounts',$where1);
		$where = ['account_id'=>$this->uri->segment(3)];
		$this->Model->deleteData('information',$where);
		$message =  base64_encode("errorrr~Athlete successfully deleted.");
		redirect(base_url('coaches/athletes/?m='.$message));
	}

	public function update_athlete(){
		$this->checkAccountNotNull();
		$gender = $this->input->post('up_gender');
		$fname = $this->input->post('up_fname');
		$lname = $this->input->post('up_lname');
		$course = $this->input->post('up_course');
		$address = $this->input->post('up_address');
		$datebirth = $this->input->post('up_datebirth');
		$course_yr = $this->input->post('up_course_yr');
		$id = $this->uri->segment(3);

		$config['upload_path'] = FCPATH."assets\images";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = 100000;
    $config['max_width'] = 5000;
    $config['max_height'] = 5000;

    $this->load->library('upload', $config);
    $image_name = $_FILES['up_pro_pic']['name'];
    $image_path = './assets/pro_pic_images/'.$image_name;
  	if($this->upload->do_upload('up_pro_pic')){
    	$image_path = $this->upload->data()['file_name'];
    	$where1 = ['id'=>$id];
			$data1 = [
				"pro_pic" => $image_path
			];

			$this->Model->update('accounts',$data1,$where1);
    }

		$where = ['account_id'=>$id];
		$info_data = [
			"firstname" => $fname,
			"lastname" => $lname,
			"birthdate" => date('Y-m-d',strtotime($datebirth)),
			"address" => $address,
			"course" => $course,
			"gender" => $gender
		];

		$this->Model->update('information',$info_data,$where);
		$message =  base64_encode("success~Athlete information successfully updated.");
		redirect(base_url('coaches/athletes/?m='.$message));
	}

	public function attendance(){
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = ['e.coach_id'=>$this->nativesession->get('id')];
		$data['allEvents'] = $this->Model->getAllEvents($where);
		$this->heading($row);
		$this->load->view('attendance',$data);
		$this->load->view('footer');
	}

	// public function athletes(){
	// 	$row1 = $this->checkAccountNotNull();
	// 	$where = ['a.usertype'=>3,'i.sports'=>$row1->sports];	
	// 	$array_results = array();
	// 	$allAthletes = $this->Model->getAthletes($where);
	// 	foreach($allAthletes as $row){
	// 		$where2 = ['coach_id' => $row1->account_id, 'date <' => date('Y-m-d') ];
	// 		$events = $this->Model->getEvents($where2);
	// 		$no_absent = 0;
	// 		foreach($events as $row2){
	// 			$where3 = [
	// 				'att_event_id' => $row2->id,
	// 				'att_account_id '=> $row->account_id
	// 			];
	// 			$result = $this->Model->getAttendancesByEventId($where3);
	// 			if($result == null){
	// 				$no_absent++;
	// 			}
	// 		}
	// 		array_push($array_results,[
	// 			'row_info' => $row,
	// 			'number_absences' => $no_absent
	// 		]);
	// 	}
	// 	$data['allResult'] = $array_results;
	// 	$data['sport'] = $row1->sports;
	// 	$this->heading($row1);
	// 	$this->load->view('athletes_status',$data);
	// 	$this->load->view('footer');
	// }

	public function checkAttendance(){
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = ['att_event_id'=>$this->uri->segment(3)];
		$attendances = $this->Model->getAttendancesByEventId($where);
		$array_athletes_id = array();
		$array_attendance = array();
		$array_remarks = array();
		if($attendances != null){
			foreach($attendances as $row1){
				array_push($array_athletes_id, $row1->att_account_id);
				array_push($array_attendance, $row1->time_present);
				array_push($array_remarks, $row1->remarks);
			}
		}
		$where1 = [
			'i.sports'=>$row->sports,
			'a.usertype'=>3
		];
		$data['AllAthletes'] = $this->Model->getAthletes($where1);

		$where2 = ['id'=>$this->uri->segment(3)];
		$data['eventRow'] = $this->Model->getEventById($where2);
		$data['arrayAccountId'] = $array_athletes_id;
		$data['arrayTimePresent'] = $array_attendance;
		$data['arrayRemarks'] = $array_remarks;
		$this->heading($row);
		$this->load->view('checkAttendance',$data);
		$this->load->view('footer');
	}

	public function present_athletes(){
		$this->checkAccountNotNull();
		$event_id = $this->input->post('hidden_event_id');
		$data = ['att_event_id'=>$event_id,'att_account_id'=>$this->uri->segment(3)];
		$this->Model->insertData('attendances',$data);

		$message =  base64_encode("success~Athlete is now present.");
		redirect(base_url('coaches/checkAttendance/'.$event_id.'?m='.$message));
	}

	public function add_remarks(){
		$this->checkAccountNotNull();
		$event_id = $this->uri->segment(4);
		$account_id = $this->uri->segment(3);
		$remarks = $this->input->post('remarks');
		$where = ['att_event_id'=>$event_id,'att_account_id'=>$account_id];
		$data = ['remarks'=>$remarks];
		$this->Model->update('attendances',$data,$where);

		$message =  base64_encode("success~Remarks successfully added.");
		redirect(base_url('coaches/checkAttendance/'.$event_id.'?m='.$message));
	}

	public function post(){
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = "p.sport_team = '$row->sports' OR p.sport_team = 'admin'";
		$data['allDocumentation'] = $this->Model->getDocumentation($where);
		$this->heading($row);
		$this->load->view('post_documentation',$data);
		$this->load->view('footer');
	}

	public function insert_documentation(){	
		$row = $this->checkAccountNotNull();
		$title = $this->input->post('title');
		$description = $this->input->post('description');
		$post_account_id = $this->nativesession->get('id');
		$sports = $row->sports;

		$config['upload_path'] = FCPATH."assets\post_images";
	    $config['allowed_types'] = 'gif|jpg|png|jpeg';
	    $config['max_size'] = 100000;
	    $config['max_width'] = 5000;
	    $config['max_height'] = 5000;

	    $this->load->library('upload', $config);
	    $image_name = $_FILES['pro_pic']['name'];
	    $image_path = './assets/pro_pic_images/'.$image_name;
	  	if(!$this->upload->do_upload('pro_pic')){
	        $message1 = $this->upload->display_errors();
	        if('You did not select a file to upload.' == $message1){
	        	$message = base64_encode("success~New user successfully added. The profile picture is default image because you didn't select an image.");
	        } else {
	        	$message =  base64_encode("success~".$message1);
	        }
	        
	        $image_path = 'pro_pic_icon_admin.png';
	    } else {
	    	$image_path = $this->upload->data()['file_name'];
	    	$message = base64_encode('success~New user successfully added.');
	    }

	    $data = [
				"title" => $title,
				"description" => $description,
				"image" => $image_path,
				"sport_team" => $sports,
				"post_account_id" => $post_account_id
			];
			$check = $this->Model->insertData('posts',$data);
			if($check != NULL){
	    	$message = base64_encode('success~New documentation successfully added.');
			} else {
				$message = base64_encode("errorrr~There's an error in saving the data. Please contact the Developer.");
			}	
	   	redirect(base_url('coaches/post/?m='.$message));
	}

	public function delete_post(){
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$this->Model->deleteData('posts',$where);
		$message =  base64_encode("errorrr~Documentation successfully deleted.");
		redirect(base_url('coaches/post/?m='.$message));
	}

	public function changeAccount(){
		$row = $this->checkAccountNotNull();
		$data['row'] = $row;
		$this->heading($row);
		$this->load->view('changeAccount',$data);
		$this->load->view('footer');
	}

	public function update_user_account(){
		$this->checkAccountNotNull();
		$id = $this->nativesession->get('id');
		$username = $this->input->post('username');
		$password = base64_encode(md5($this->input->post('password')));
		$data = ['username'=>$username,'password'=>$password,'updated'=>1];
		$where = ['id'=>$id];
		$this->Model->update('accounts',$data,$where);
		$message = base64_encode("success~Your username and password successfully updated.");
		redirect(base_url('coaches/?m='.$message));
	}

	public function profile(){
		$row = $this->checkAccountNotNull();
		// var_dump($row);exit;
		$data['hresult'] = $row;
		$this->heading($row);
		$this->load->view('profile',$data);
		$this->load->view('footer');
	}

	public function update_profile(){
		$row = $this->checkAccountNotNull();
		$lname = $this->input->post('lname');
		$fname = $this->input->post('fname');
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$config['upload_path'] = FCPATH."assets\images";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = 100000;
    $config['max_width'] = 5000;
    $config['max_height'] = 5000;

    $this->load->library('upload', $config);
    $image_name = $_FILES['pro_pic']['name'];
    $image_path = './assets/pro_pic_images/'.$image_name;
  	if($this->upload->do_upload('pro_pic')){
    	$image_path = $this->upload->data()['file_name'];
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path
				];
			}
			$this->Model->update('accounts',$data_account,$where1);
    } else {
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username
				];
			}
			$this->Model->update('accounts',$data_account,$where1);
    }
		$where = ['account_id'=>$this->nativesession->get('id')];
		$data = [
			"firstname" => $fname,
			"lastname" => $lname
		];
		// var_dump($data);exit;
		$this->Model->update('information',$data,$where);

		$message =  base64_encode("success~Admin information successfully updated.");
		redirect(base_url('coaches/profile/?m='.$message));
	}

	function heading($row){
		$data['hresult'] = $row;
		$this->load->view('head.php');
		$this->load->view('header.php',$data);
	}

	function checkAccountNotNull(){
		$id = $this->nativesession->get('id');
		if($id == NULL){
			$message = base64_encode("errorrr~You have to login first before you can access the page.");
			redirect(base_url('?m='.$message));
		} else {
			$where = array(
				'a.id' => $id
			);
			$rows = $this->Model->CheckAccount( 'accounts' , $where );

			if($rows->usertype != 2){
				$message = base64_encode("errorrr~Restricted page. Your account is not coach type.");
				redirect(base_url('?m='.$message));
			} else {
				return $rows;
			}
			
		}
	}

	function checkAccountUpdated($row){
		if($row->updated == 0){
			$message = base64_encode("errorrr~Before continuing, update your account.");
			redirect(base_url('coaches/changeAccount/?m='.$message));
		}
	}
	
}
