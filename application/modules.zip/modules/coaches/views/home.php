  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Scan QR Code</h1>
          </div>
          <div class="col-sm-6">
            <h1 class="m-0">Attendance Logs</h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <center>
              <input type="hidden" id="hidden_time_inout" value="visit_office">
              <h4><span id='date'></span> <span id='time'></span></h4>
            </center>
            
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="card card-primary card-outline">
              <div class="card-body">
                <div class="container">
                  <video id="preview" style="width: 100%; height: 350px;"></video>
                </div>
              </div>
            </div><!-- /.card -->
          </div>
          <!-- /.col-md-6 -->
          <div class="col-lg-6">
            <div class="card card-warning card-outline">
              <div class="card-body table-responsive p-0" style="height: 396px;">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th colspan="2">LOGS</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($all_logs as $value) {?>
                    <tr>
                      <td><?php echo date('F d, Y', strtotime($value->date_log));?></td>
                      <td><?php echo $value->firstname.' '.$value->lastname.' '.$value->name_log.' at '.$value->time.'.';?></td>
                    </tr>
                    <?php }?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <button type="button" class="btn btn-default" id="hidden_modal" data-toggle="modal" data-target="#modal-default" hidden></button>
  <!-- /.content-wrapper -->
  <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Default Modal</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>One fine body&hellip;</p>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->