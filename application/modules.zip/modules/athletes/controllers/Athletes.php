<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Athletes extends MX_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->model(array('Model'));
    } 
    
	public function index()
	{		
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$where = [
			'i.sports'=>$row->sports,
			 'a.usertype' => 2
		];
		$getCoachData = $this->Model->CheckAccount('accounts',$where);
		$where = ['e.coach_id'=>$getCoachData->account_id,'date >= ' => date('Y-m-d')];
		$data['allEvents'] = $this->Model->getAllEvents($where);
		$this->heading($row);
		$this->load->view('upcoming_events',$data);
		$this->load->view('footer');
	} 

	public function view_Attendance(){
		$row = $this->checkAccountNotNull();
		$where = [
			'i.sports'=>$row->sports,
			 'a.usertype' => 2
		];
		$getCoachData = $this->Model->CheckAccount('accounts',$where);
		$where = ['e.coach_id'=>$getCoachData->account_id,'date < ' => date('Y-m-d')];
		$allEvents = $this->Model->getAllEvents($where);
		$array_result = array();
		foreach($allEvents as $value){
			$where1 = ['att_event_id'=>$value->event_id,'att_account_id' => $row->account_id];
			$checkResult = $this->Model->getAttendancesByEventId($where1);
			if($checkResult != null){
				$status = 'Present';
			} else {
				$status = 'Absent';
			}
			array_push($array_result,[
				'eventRow' => $value,
				'status' => $status
			]);
		}
		$data['result'] = $array_result;
		$this->heading($row);
		$this->load->view('view_attendance',$data);
		$this->load->view('footer');
	}

	public function post(){
		$row = $this->checkAccountNotNull();
		$where = "p.sport_team = '$row->sports' OR p.sport_team = 'admin'";;
		$data['allDocumentation'] = $this->Model->getDocumentation($where);
		$this->heading($row);
		$this->load->view('post_documentation',$data);
		$this->load->view('footer');
	}

	public function changeAccount(){
		$row = $this->checkAccountNotNull();
		$data['row'] = $row;
		$this->heading($row);
		$this->load->view('changeAccount',$data);
		$this->load->view('footer');
	}

	public function update_user_account(){
		$row = $this->checkAccountNotNull();
		$id = $this->nativesession->get('id');
		$username = $this->input->post('username');
		$password = base64_encode(md5($this->input->post('password')));
		$data = ['username'=>$username,'password'=>$password,'updated'=>1];
		$where = ['id'=>$id];
		$this->Model->update('accounts',$data,$where);
		$message = base64_encode("success~Your username and password successfully updated.");
		redirect(base_url('athletes/?m='.$message));
	}

	public function profile(){
		$row = $this->checkAccountNotNull();
		$this->checkAccountUpdated($row);
		$data['hresult'] = $row;
		$this->heading($row);
		$this->load->view('profile',$data);
		$this->load->view('footer');
	}

	public function update_profile(){
		$row = $this->checkAccountNotNull();
		$lname = $this->input->post('lname');
		$fname = $this->input->post('fname');
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$config['upload_path'] = FCPATH."assets\images";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = 100000;
    $config['max_width'] = 5000;
    $config['max_height'] = 5000;

    $this->load->library('upload', $config);
    $image_name = $_FILES['pro_pic']['name'];
    $image_path = './assets/pro_pic_images/'.$image_name;
  	if($this->upload->do_upload('pro_pic')){
    	$image_path = $this->upload->data()['file_name'];
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path
				];
			}
			$this->Model->update('accounts',$data_account,$where1);
    } else {
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username
				];
			}
			$this->Model->update('accounts',$data_account,$where1);
    }
		$where = ['account_id'=>$this->nativesession->get('id')];
		$data = [
			"firstname" => $fname,
			"lastname" => $lname
		];
		// var_dump($data);exit;
		$this->Model->update('information',$data,$where);

		$message =  base64_encode("success~Admin information successfully updated.");
		redirect(base_url('atheltes/profile/?m='.$message));
	}

	function heading($row){
		$data['hresult'] = $row;
		$this->load->view('head.php');
		$this->load->view('header.php',$data);
	}

	public function logout(){	
		$this->nativesession->delete('id');
		redirect(base_url());
	}

	function checkAccountNotNull(){
		$id = $this->nativesession->get('id');
		if($id == NULL){
			$message = base64_encode("errorrr~You have to login first before you can access the page.");
			redirect(base_url('?m='.$message));
		} else {
			$where = array(
				'a.id' => $id
			);
			$rows = $this->Model->CheckAccount( 'accounts' , $where );

			if($rows->usertype != 3){
				$message = base64_encode("errorrr~Restricted page. Your account is not athlete type.");
				redirect(base_url('?m='.$message));
			} else {
				return $rows;
			}
			
		}
	}

	function checkAccountUpdated($row){
		if($row->updated == 0){
			$message = base64_encode("errorrr~Before continuing, update your account.");
			redirect(base_url('athletes/changeAccount/?m='.$message));
		}
	}
	
}
