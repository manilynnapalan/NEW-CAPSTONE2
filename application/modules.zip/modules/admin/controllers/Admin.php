<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MX_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->model(array('Adm_model'));
        $this->load->library(array('qrlib'));

        // var_dump(base64_encode(md5('12345')));exit;
    } 
    
	public function index()
	{	
		$this->load->view('login_page');
	}

	public function login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' => base64_encode(md5($password))
		);
		$rows = $this->Adm_model->CheckAccount( 'accounts' , $where );
		if($rows != NULL){
			if($rows->usertype == 1){
				$this->nativesession->set('id',$rows->account_id);
				$message = base64_encode('success~Welcome '.$rows->username.'!');
				redirect(base_url('admin/home/?m='.$message));
			} else if($rows->usertype == 2){
				$this->nativesession->set('id',$rows->account_id);
				$message = base64_encode('success~Welcome '.$rows->username.'!');
				redirect(base_url('coaches/?m='.$message));
			} else if($rows->usertype == 3){
				$this->nativesession->set('id',$rows->account_id);
				$message = base64_encode('success~Welcome '.$rows->username.'!');
				redirect(base_url('athletes/?m='.$message));
			}
		} else {
			$message = base64_encode("errorrr~Incorrect username or password.");
			redirect(base_url('/?m='.$message));
		}
	}

	public function home(){
		$account_id = $this->nativesession->get('id');
		$row = $this->checkAccountNotNull();
		$this->heading($row);
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$data['array_result'] = array();
		foreach($data['allSports'] as $row){
			$result = $this->Adm_model->getRowsBySports($row->sport_name);
			array_push($data['array_result'], array(
				'sport_name' => $row->sport_name,
				'num_rows' => count($result)
			));
		}
		$data['allEvents'] = $this->Adm_model->getAllEventsFooter();
		$this->load->view('home',$data);
		$this->load->view('footer',$data);
	}

	public function athletes(){
		$account_id = $this->nativesession->get('id');
		$row = $this->checkAccountNotNull();
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$data['allData'] = $this->Adm_model->getAllRowsByUsertype(3);
		$this->heading($row);
		$this->load->view('athletes',$data);
		$this->load->view('footer');
	}

	public function insert_athletes(){	
		$username = $this->input->post('id_number');
		$where = array(
			'username' => $username
		);
		$checkUN = $this->Adm_model->CheckAccount('accounts',$where);
		if($checkUN == NULL){
			$gender = $this->input->post('gender');
			$sport = $this->input->post('sport');
			$fname = $this->input->post('fname');
			$lname = $this->input->post('lname');
			$course = $this->input->post('course');
			$address = $this->input->post('address');
			$datebirth = $this->input->post('datebirth');
			$course_yr = $this->input->post('course_yr');

			$config['upload_path'] = FCPATH."assets\images";
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = 100000;
      $config['max_width'] = 5000;
      $config['max_height'] = 5000;

      $this->load->library('upload', $config);
      $image_name = $_FILES['pro_pic']['name'];
      $image_path = './assets/pro_pic_images/'.$image_name;
      	if(!$this->upload->do_upload('pro_pic')){
            $message1 = $this->upload->display_errors();
            if('You did not select a file to upload.' == $message1){
            	$message = base64_encode("success~New user successfully added. The profile picture is default image because you didn't select an image.");
            } else {
            	$message =  base64_encode("success~".$message1);
            }
            
            $image_path = 'pro_pic_icon_admin.png';
        } else {
        	$image_path = $this->upload->data()['file_name'];
        	$message = base64_encode('success~New user successfully added.');
        }

        $accounts_data = [
					"username" => $username,
					"password" => base64_encode(md5('123456')),
					"pro_pic" => $image_path,
					"usertype" => 3
				];

				$account_id = $this->Adm_model->insertData('accounts',$accounts_data);
		        
		    $info_data = [
					"account_id" => $account_id,
					"firstname" => $fname,
					"lastname" => $lname,
					"birthdate" => date('Y-m-d',strtotime($datebirth)),
					"address" => $address,
					"course" => $course,
					"gender" => $gender,
					"sports" => $sport
				];
				$check = $this->Adm_model->insertData('information',$info_data);
				if($check != NULL){
        	$message = base64_encode('success~New user successfully added.');
				} else {
					$message = base64_encode("errorrr~There's an error in saving the data. Please contact the Developer.");
				}	
    } else {
    	$message = base64_encode('errorrr~Username has been used.');
    }
   	redirect(base_url('admin/athletes/?m='.$message));
	}

	public function update_athletes(){
		$this->checkAccountNotNull();
		$gender = $this->input->post('up_gender');
		$sport = $this->input->post('up_sport');
		$fname = $this->input->post('up_fname');
		$lname = $this->input->post('up_lname');
		$course = $this->input->post('up_course');
		$address = $this->input->post('up_address');
		$datebirth = $this->input->post('up_datebirth');
		$course_yr = $this->input->post('up_course');
		$id = $this->uri->segment(3);

		$config['upload_path'] = FCPATH."assets\images";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = 100000;
    $config['max_width'] = 5000;
    $config['max_height'] = 5000;

    $this->load->library('upload', $config);
    $image_name = $_FILES['pro_pic']['name'];
    $image_path = './assets/pro_pic_images/'.$image_name;
  	if($this->upload->do_upload('pro_pic')){
    	$image_path = $this->upload->data()['file_name'];
    	$where1 = ['id'=>$id];
			$data1 = [
				"pro_pic" => $image_path
			];

			$this->Adm_model->updateData('accounts',$data1,$where1);
    }

		$where = ['account_id'=>$id];
		$info_data = [
			"firstname" => $fname,
			"lastname" => $lname,
			"birthdate" => date('Y-m-d',strtotime($datebirth)),
			"address" => $address,
			"course" => $course,
			"gender" => $gender,
			"sports" => $sport
		];

		$this->Adm_model->updateData('information',$info_data,$where);
		$message =  base64_encode("success~Athlete information successfully updated.");
		redirect(base_url('admin/athletes/?m='.$message));
	}

	public function delete_athletes(){
		$this->checkAccountNotNull();
		$where1 = ['id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('accounts',$where1);
		$where = ['account_id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('information',$where);
		$message =  base64_encode("errorrr~Athlete successfully deleted.");
		redirect(base_url('admin/athletes/?m='.$message));
	}

	public function coaches(){
		$row = $this->checkAccountNotNull();
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$data['allCoaches'] = $this->Adm_model->getAllRowsByUsertype(2);
		$this->heading($row);
		$this->load->view('coaches',$data);
		$this->load->view('footer');
	}

	public function insert_reg(){	
		$fname = $this->input->post('fname');
		$lname = $this->input->post('lname');
		$username = $this->input->post('username');
		$where = array(
			'username' => $username
		);
		$checkUN = $this->Adm_model->CheckAccount('accounts',$where);
		if($checkUN == NULL){
			$gender = $this->input->post('gender');
			$sport = $this->input->post('sport');

			$config['upload_path'] = FCPATH."assets\images";
      $config['allowed_types'] = 'gif|jpg|png|jpeg';
      $config['max_size'] = 100000;
      $config['max_width'] = 5000;
      $config['max_height'] = 5000;

      $this->load->library('upload', $config);
      $image_name = $_FILES['pro_pic']['name'];
      $image_path = './assets/pro_pic_images/'.$image_name;
      	if(!$this->upload->do_upload('pro_pic')){
            $message1 = $this->upload->display_errors();
            if('You did not select a file to upload.' == $message1){
            	$message = base64_encode("success~New user successfully added. The profile picture is default image because you didn't select an image.");
            } else {
            	$message =  base64_encode("success~".$message1);
            }
            
            $image_path = 'pro_pic_icon_admin.png';
        } else {
        	$image_path = $this->upload->data()['file_name'];
        	$message = base64_encode('success~New user successfully added.');
        }

        $accounts_data = [
					"username" => $username,
					"password" => base64_encode(md5('123456')),
					"pro_pic" => $image_path,
					"usertype" => 2
				];

				$account_id = $this->Adm_model->insertData('accounts',$accounts_data);
		        
		    $info_data = [
					"account_id" => $account_id,
					"firstname" => $fname,
					"lastname" => $lname,
					"gender" => $gender,
					"sports" => $sport
				];

				$check = $this->Adm_model->insertData('information',$info_data);
				if($check != NULL){
        	$message = base64_encode('success~New user successfully added.');
				} else {
					$message = base64_encode("errorrr~There's an error in saving the data. Please contact the Developer.");
				}	
    } else {
    	$message = base64_encode('errorrr~Username has been used.');
    }
   	redirect(base_url('admin/coaches/?m='.$message));
	}

	public function update_data(){
		$this->checkAccountNotNull();
		$fname = $this->input->post('fname');
		$lname = $this->input->post('lname');
		$gender = $this->input->post('gender');
		$sport = $this->input->post('sport');
		$password = $this->input->post('password');

		if($password != null){
			$where1 = ['account_id'=>$this->uri->segment(3)];
			$data1 = [
				"password" => base64_encode(md5($password))
			];
			$this->Adm_model->updateData('accounts',$data1,$where1);
		}
		$where = ['account_id'=>$this->uri->segment(3)];
		$data = [
			"firstname" => $fname,
			"lastname" => $lname,
			"gender" => $gender,
			"sports" => $sport
		];

		$this->Adm_model->updateData('information',$data,$where);
		$message =  base64_encode("success~Coach information successfully updated.");
		redirect(base_url('admin/coaches/?m='.$message));
	}

	public function delete_coach(){
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('accounts',$where);

		$where1 = ['account_id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('information',$where1);
		$message =  base64_encode("errorrr~Coach information successfully deleted.");
		redirect(base_url('admin/coaches/?m='.$message));
	}

	public function sports(){
		$account_id = $this->nativesession->get('id');
		$row = $this->checkAccountNotNull();
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$this->heading($row);
		$this->load->view('sports',$data);
		$this->load->view('footer');
	}

	public function insert_sport(){
		$account_id = $this->nativesession->get('id');
		$this->checkAccountNotNull();
		$data = ['sport_name'=>$this->input->post('sport')];
		$check = $this->Adm_model->checkDuplicateData('sports',$data);
		if($check != null){
			$message =  base64_encode("errorrr~Team sport already exist!");
		} else {
			$this->Adm_model->insertData('sports',$data);
			$message =  base64_encode("success~Team sport successfully added.");
		}
		redirect(base_url('admin/sports/?m='.$message));
	}

	public function update_sport(){
		$account_id = $this->nativesession->get('id');
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$data = ['sport_name'=>$this->input->post('sport')];
		$check = $this->Adm_model->checkDuplicateData('sports',$data);
		if($check != null){
			$message =  base64_encode("errorrr~Team sport already exist!");
		} else {
			$this->Adm_model->updateData('sports',$data,$where);
			$message =  base64_encode("success~Team sport successfully updated.");
		}
		redirect(base_url('admin/sports/?m='.$message));
	}

	public function delete_sport(){
		$account_id = $this->nativesession->get('id');
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('sports',$where);
		$message =  base64_encode("errorrr~Team sport successfully deleted.");
		redirect(base_url('admin/sports/?m='.$message));
	}

	public function attendance(){
		$row = $this->checkAccountNotNull();
		if($this->input->get('ts') != null){
			$where = ['i.sports'=>$this->input->get('ts')];	
		} else {
			$where = [];	
		}
		
		$data['allEvents'] = $this->Adm_model->getAllEvents($where);
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$this->heading($row);
		$this->load->view('attendance',$data);
		$this->load->view('footer');
	}

	public function checkAttendance(){
		$row = $this->checkAccountNotNull();
		$where = ['att_event_id'=>$this->uri->segment(3)];
		$attendances = $this->Adm_model->getAttendancesByEventId($where);
		$array_athletes_id = array();
		$array_attendance = array();
		$array_remarks = array();
		if($attendances != null){
			foreach($attendances as $row1){
				array_push($array_athletes_id, $row1->att_account_id);
				array_push($array_attendance, $row1->time_present);
				array_push($array_remarks, $row1->remarks);
			}
		}
		$where2 = ['e.id'=>$this->uri->segment(3)];
		$data['eventRow'] = $this->Adm_model->getEventById($where2);
		// var_dump($data['eventRow'] );exit;
		$where1 = [
			'i.sports'=>$data['eventRow']->sports,
			'a.usertype'=>3
		];
		$data['AllAthletes'] = $this->Adm_model->getAthletes($where1);
		$no_presents = 0;
		foreach ($data['AllAthletes'] as $row) {
			if(in_array($row->account_id, $array_athletes_id)){
				$no_presents++;
			}
		}

		$data['arrayAccountId'] = $array_athletes_id;
		$data['arrayTimePresent'] = $array_attendance;
		$data['arrayRemarks'] = $array_remarks;
		$data['noPresents'] = $no_presents;
		$this->heading($row);
		$this->load->view('checkAttendance',$data);
		$this->load->view('footer');
	}

	public function athleteStatus(){
		$row6 = $this->checkAccountNotNull();
		if(@$this->input->get('ts') != null){
			$where = ['a.usertype'=>3,'i.sports'=>$this->input->get('ts')];	
		} else {
			$where = ['a.usertype'=>3];	
		}
		$array_results = array();
		$allAthletes = $this->Adm_model->getAthletes($where);
		
		foreach($allAthletes as $row){
			$where1 = ['i.sports'=>$row->sports,'a.usertype'=>2];
			$coach_row = $this->Adm_model->CheckAccount('accounts',$where1);
			$where2 = ['coach_id'=>$coach_row->account_id,'date <'=>date('Y-m-d')];
			$events = $this->Adm_model->getEventsByCoachID($where2);
			$no_absent = 0;
			foreach($events as $row1){
				$where3 = [
					'att_event_id' => $row1->id,
					'att_account_id '=> $row->account_id
				];
				$result = $this->Adm_model->getAttendancesByEventId($where3);
				if($result == null){
					$no_absent++;
				}
			}
			array_push($array_results,[
				'row_info' => $row,
				'coach' => $coach_row,
				'number_absences' => $no_absent
			]);
		}
		$data['allResult'] = $array_results;
		$data['allSports'] = $this->Adm_model->getAllSPorts();
		$this->heading($row6);
		$this->load->view('athletes_status',$data);
		$this->load->view('footer');
	}

	public function post(){
		$row = $this->checkAccountNotNull();
		$data['allDocumentation'] = $this->Adm_model->getDocumentation();
		$this->heading($row);
		$this->load->view('post_documentation',$data);
		$this->load->view('footer');
	}

	public function insert_documentation(){	
		$row = $this->checkAccountNotNull();
		$title = $this->input->post('title');
		$description = $this->input->post('description');
		$post_account_id = $this->nativesession->get('id');
		$sports = $row->sports;

		$config['upload_path'] = FCPATH."assets\post_images";
	    $config['allowed_types'] = 'gif|jpg|png|jpeg';
	    $config['max_size'] = 100000;
	    $config['max_width'] = 5000;
	    $config['max_height'] = 5000;

	    $this->load->library('upload', $config);
	    $image_name = $_FILES['pro_pic']['name'];
	    $image_path = './assets/pro_pic_images/'.$image_name;
	  	if(!$this->upload->do_upload('pro_pic')){
	        $message1 = $this->upload->display_errors();
	        if('You did not select a file to upload.' == $message1){
	        	$message = base64_encode("success~New user successfully added. The profile picture is default image because you didn't select an image.");
	        } else {
	        	$message =  base64_encode("success~".$message1);
	        }
	        
	        $image_path = 'pro_pic_icon_admin.png';
	    } else {
	    	$image_path = $this->upload->data()['file_name'];
	    	$message = base64_encode('success~New user successfully added.');
	    }

	    $data = [
				"title" => $title,
				"description" => $description,
				"image" => $image_path,
				"sport_team" => 'admin',
				"post_account_id" => $row->account_id
			];
			$check = $this->Adm_model->insertData('posts',$data);
			if($check != NULL){
	    	$message = base64_encode('success~New documentation successfully added.');
			} else {
				$message = base64_encode("errorrr~There's an error in saving the data. Please contact the Developer.");
			}	
	   	redirect(base_url('admin/post/?m='.$message));
	}

	public function delete_post(){
		$this->checkAccountNotNull();
		$where = ['id'=>$this->uri->segment(3)];
		$this->Adm_model->deleteData('posts',$where);
		$message =  base64_encode("errorrr~Documentation successfully deleted.");
		redirect(base_url('admin/post/?m='.$message));
	}

	public function profile(){
		$row = $this->checkAccountNotNull();
		// var_dump($row);exit;
		$data['hresult'] = $row;
		$this->heading($row);
		$this->load->view('profile',$data);
		$this->load->view('footer');
	}

	public function update_profile(){
		$row = $this->checkAccountNotNull();
		$lname = $this->input->post('lname');
		$fname = $this->input->post('fname');
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$config['upload_path'] = FCPATH."assets\images";
    $config['allowed_types'] = 'gif|jpg|png|jpeg';
    $config['max_size'] = 100000;
    $config['max_width'] = 5000;
    $config['max_height'] = 5000;

    $this->load->library('upload', $config);
    $image_name = $_FILES['pro_pic']['name'];
    $image_path = './assets/pro_pic_images/'.$image_name;
  	if($this->upload->do_upload('pro_pic')){
    	$image_path = $this->upload->data()['file_name'];
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username,
					"pro_pic" => $image_path
				];
			}
			$this->Adm_model->update('accounts',$data_account,$where1);
    } else {
    	$where1 = ['id'=>$this->nativesession->get('id')];
			if($password != null){
				$data_account = [
					'username' => $username,
					'password' => base64_encode(md5($password))
				];
			} else {
				$data_account = [
					'username' => $username
				];
			}
			$this->Adm_model->update('accounts',$data_account,$where1);
    }
		$where = ['account_id'=>$this->nativesession->get('id')];
		$data = [
			"firstname" => $fname,
			"lastname" => $lname
		];

		$this->Adm_model->updateData('information',$data,$where);

		$message =  base64_encode("success~Admin information successfully updated.");
		redirect(base_url('admin/profile/?m='.$message));
	}

	function heading($row){
		$data['hresult'] = $row;
		$this->load->view('head.php');
		$this->load->view('header.php',$data);
	}

	public function logout()
	{	
		$this->nativesession->delete('id');
		redirect(base_url());
	}

	function checkAccountNotNull(){
		$id = $this->nativesession->get('id');
		if($id == NULL){
			$message = base64_encode("errorrr~You have to login first before you can access the page.");
			redirect(base_url('?m='.$message));
		} else {
			$where = array(
				'a.id' => $id
			);
			$rows = $this->Adm_model->CheckAccount( 'accounts' , $where );
			if($rows->usertype != 1){
				$message = base64_encode("errorrr~Restricted page. Your account is not an admin type.");
				redirect(base_url('?m='.$message));
			} else {
				return $rows;
			}
			
		}
	}
}
